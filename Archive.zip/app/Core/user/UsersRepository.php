<?php

namespace App\Core\user;

use GuzzleHttp\Client;

class UsersRepository implements IUserRepository
{

}