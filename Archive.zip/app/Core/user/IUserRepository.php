<?php

namespace App\Core\user;

interface IUserRepository
{
    //public function get_users();

}