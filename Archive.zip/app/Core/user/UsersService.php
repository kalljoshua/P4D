<?php

namespace App\Core\user;

class UsersService
{
    private IUserRepository $repository;
}